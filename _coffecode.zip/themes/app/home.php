<?php $v->layout("_theme") ?>
 
<div class="container mt-5">
  <h1>Olá, <?= $user->fullname() ?></h1>
</div>