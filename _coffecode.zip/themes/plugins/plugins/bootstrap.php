<div style="padding: 10px;">
    <div class="highlight"><pre class="chroma">
        <code class="language-html" data-lang="html"><span class="p">&lt;</span><span class="nt">link</span> <span class="na">href</span><span class="o">=</span><span class="s">"< ?=url("/shared/bootstrap/css/bootstrap.min.css")  ?>"</span> <span class="na">rel</span><span class="o">=</span><span class="s">"stylesheet"</span> <span class="p">&gt;</span>
        <span class="p">&lt;</span><span class="nt">script</span> <span class="na">src</span><span class="o">=</span><span class="s">"< ?= url("/shared/bootstrap/js/bootstrap.min.js")  ?>"</span><span class="p">&gt;&lt;/</span><span class="nt">script</span><span class="p">&gt;</span>
        </code></pre>
    </div>  
</div>


