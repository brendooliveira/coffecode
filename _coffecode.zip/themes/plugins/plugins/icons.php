<div class="card-body">
    <div class="row">
        <div class="col-2 mb-3">
            <i class="bi bi-activity"></i>
        </div>
        <div class="col-2 mb-3">
            <i class="bi bi-alarm-fill"></i>
        </div>
        <div class="col-2 mb-3">
            <i class="bi bi-alarm"></i>
        </div>
        <div class="col-2 mb-3">
            <i class="bi bi-align-bottom"></i>
        </div>
        <div class="col-2 mb-3">
            <i class="bi bi-align-center"></i>
        </div>
        <div class="col-2 mb-3">
            <i class="bi bi-align-end"></i>
        </div>
        <div class="col-2 mb-3">
            <i class="bi bi-align-middle"></i>
        </div>
        <div class="col-2 mb-3">
            <i class="bi bi-align-start"></i>
        </div>
        <div class="col-2 mb-3">
            <i class="bi bi-align-top"></i>
        </div>
        <div class="col-2 mb-3">
            <i class="bi bi-alt"></i>
        </div>
    </div>
</div>