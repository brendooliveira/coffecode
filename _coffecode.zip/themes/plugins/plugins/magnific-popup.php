<div class="container mb-3 mt-3">
    <div class="row parent-container">
        <div class="col-lg-6"><a href="https://via.placeholder.com/600/f2f2f2/c3c3c3/?text=Meus-modelos-fsphp"><img src="https://via.placeholder.com/600/f2f2f2/c3c3c3/?text=Meus-modelos-fsphp" class="img-fluid"></a></div>
        <div class="col-lg-6"><a href="https://via.placeholder.com/600/f2f2f2/c3c3c3/?text=Meus-modelos-fsphp-2"><img src="https://via.placeholder.com/600/f2f2f2/c3c3c3/?text=Meus-modelos-fsphp-2" class="img-fluid"></a></div>
    </div>
</div>

<script>
    $(document).ready(function() {
    $('.parent-container').magnificPopup({
        delegate: 'a', // child items selector, by clicking on it popup will open
        type: 'image',
        gallery:{enabled:true}
        // other options
    });
    });
</script>