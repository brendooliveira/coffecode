<?php $v->layout("_theme") ?>

<div class="container mt-5 text-center">
    <i class="bi bi-cup-hot-fill" style="font-size: 2em; color:blue"></i>
    <h2 class="logo mb-5 ">COFFE CODE</h2>
    <p>version Coffe Code 1.0 - PHP version: 7.4.29</p>


    <a href="<?= url("/plugins") ?>">VER PLUGINS INSTALADOS</a>
</div>



